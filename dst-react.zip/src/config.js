"use strict";

var rest = {
		url: "localhost:3002/rest/"

};

exports.rest = rest;